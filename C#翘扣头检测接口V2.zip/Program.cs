﻿using System;
using System.Diagnostics;
using Emgu.CV.Structure;
using Emgu.CV;
using System.Collections;
using System.IO;
using System.Collections.Generic;
using System.Drawing;

namespace testDLL
{
    class Program
    {
        public static String[] GetFilesFrom(String searchFolder, String[] filters, bool isRecursive)
        {
            List<String> filesFound = new List<String>();
            var searchOption = isRecursive ? SearchOption.AllDirectories : SearchOption.TopDirectoryOnly;
            foreach (var filter in filters)
            {
                filesFound.AddRange(Directory.GetFiles(searchFolder, String.Format("*.{0}", filter), searchOption));
            }
            return filesFound.ToArray();
        }
        /* conversion */
        //convert image to bytearray
        public static byte[] imgToByteArray(Image img)
        {
            using (MemoryStream mStream = new MemoryStream())
            {
                img.Save(mStream, img.RawFormat);
                return mStream.ToArray();
            }
        }
        //convert bytearray to image
        public static Image byteArrayToImage(byte[] byteArrayIn)
        {
            using (MemoryStream mStream = new MemoryStream(byteArrayIn))
            {
                return Image.FromStream(mStream);
            }
        }


        /* MAIN */
        static void Main(string[] args)
        {

            String searchFolder = @"C:/Users/Zhigonghui/Desktop/testEmgu1/testEmgu1/img";
            //String searchFolder = @"C:\Users\Zhigonghui\source\repos\testDLL\testDLL\imgs";
            var filters = new String[] { "jpg" };
            var files = GetFilesFrom(searchFolder, filters, false);

            Stopwatch stopWatch = new Stopwatch();
            stopWatch.Start();

            TimeSpan ts = stopWatch.Elapsed;

            // USING EMGU.CV DEMO
            for (int num = 0; num < files.Length; num++)
            {
                Image<Gray, byte> img_input = new Image<Gray, byte>(files[num].ToString()); // read emgu image from path

                Bitmap masterImage = new Bitmap(files[num].ToString()); // read drawing image from path
                Image i = masterImage;
                ImageConverter converter = new ImageConverter();

                // convert drawing image to byte[]
                byte[] byte3 = imgToByteArray(i);
                byteArrayToImage(byte3);
                detectQKT mydeteect = new detectQKT();
                ArrayList results_detection = mydeteect.DoDetection(byte3); // resulting image, bw image, points location

                /* RESULT IMAGE FROM BYTE */
                Image img_measured = byteArrayToImage((byte[])results_detection[0]);
                Image img_measured1 = byteArrayToImage((byte[])results_detection[1]);

                //Image<Gray, byte> img_measured = (Image<Gray, byte>)results_detection[0]; // cast Typle : Image<Gray, byte>
                //Image<Gray, byte> img_measured1 = (Image<Gray, byte>)results_detection[1];
            
                ArrayList points = (ArrayList)results_detection[2]; // cast Typle : ArrayList
            

                /* SAVE EMGU IMAGE */

                //img_measured.Save("C:/Users/Zhigonghui/Desktop/testEmgu1/testEmgu1/img/1/" + num.ToString() + "_origianl.JPG");
                //img_measured1.Save("C:/Users/Zhigonghui/Desktop/testEmgu1/testEmgu1/img/1/" + num.ToString() + "_BW.JPG");
                //ImageViewer.Show(img_measured);


                /* TEST RESULTS 

                Bitmap bmpTif1 = new Bitmap(img_measured);
                Bitmap bmp = bmpTif1.Clone(new Rectangle(0, 0, img_input.Cols, img_input.Rows),System.Drawing.Imaging.PixelFormat.Format32bppRgb);
                Graphics g = Graphics.FromImage(bmp);
                g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAlias;

                for (int t = 0; t < points.Count; t++)
                {                  
                    g.DrawString("+", new Font("Tahoma", 15), Brushes.Green, (Point)points[t]);
                }
                bmp.Save(@"C:\Users\Zhigonghui\Desktop\testEmgu1\testEmgu1\img/"+num.ToString()+".JPG");

                */

            }

            stopWatch.Stop();
            Debug.WriteLine("RunTime " + stopWatch.Elapsed);
            


            // USING MATLAB DLL DEMO
            /*   
            MLApp.MLApp matlab = new MLApp.MLApp();
            matlab.Execute(@"cd D:\工业视觉项目\BS翘扣头\翘扣头图像");
            object result = null;
            matlab.Feval("imread", 1, out result, "D:/工业视觉项目/BS翘扣头/翘扣头图像/NGs2/120608251400_1_2.jpg");
            var res = result as object[];
            byte[,] img_byte = (byte[,])res[0];

            /*
            int width = img.GetLength(0);
            int height = img.GetLength(1);
            int stride = width * 4;

            double[,] integers = new double[width, height];

            for (int x = 0; x < width; ++x)
            {
                for (int y = 0; y < height; ++y)
                {
                    integers[x, y] = img[x,y];
                }
            }
            
            //            object results_output = null;
            //            matlab.Feval("MWdetectBoudary", 2, out results_output, img);



            QKTclass mydetect = new QKTclass();
            MWArray[] resultsarrray = mydetect.MWDLLDetectQKT(2, (MWNumericArray)img_byte);
            MWNumericArray _output0 = (MWNumericArray)resultsarrray[0];
            MWNumericArray _output1 = (MWNumericArray)resultsarrray[1];
            Array byte_outputIMG = _output0.ToArray();
            Array byte_outputPoints = _output1.ToArray();

            */


        }
    }
}
